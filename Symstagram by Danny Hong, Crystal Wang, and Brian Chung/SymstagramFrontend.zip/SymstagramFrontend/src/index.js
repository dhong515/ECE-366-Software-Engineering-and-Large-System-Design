import React from 'react'
import ReactDOM from 'react-dom'
import App from './login'
import Mainpage from './Mainpage'

// display the page
ReactDOM.render(<App />, document.getElementById('index_root'));